fresh=input('fresh? 0, 1, 2, 3, 4');
%to continue an ongoing simulation, enter "0"
%to load a saved simulation, make sure the correct file will be loaded
%(line 37) and enter "1"
%to initialize a simulation with an initial RM frequency of 80% (50%,
%20%), enter "2" ("3", "4")

envi=2; %1 for E3A, 2 for E3B
psize=100; %size of simulated population
basepop=zeros(psize,2); %initialize the population vector
rounds=50; %number of generations simulated when script is executed
life=50; %length of generation (measured in decisions made)

B=11; %in E3B, HS choices are B times more consequential than non-HS choices
p=.02; %in E3B, p(HS)
lo=-300; %in E3A, reward when attribute value is in [0,10] (see Fig 3A)

%Note on population vector, column 1: every row represents an organism; the
%values "0" and "1" respectively correspond to BH and RM organisms

if fresh>0
    switch fresh
        case 2 %initial frequency of RM is 80%
            basepop(psize*.2+1:100,1)=1;
        case 3 %...50%
            basepop(psize*.5+1:100,1)=1;
        case 4 %...20%
            basepop(psize*.8+1:100,1)=1;
    end
    decimatepop=basepop; halfdiepop=basepop; mostdiepop=basepop;
    %the above variables initiate a population correponding to each of the
    %survival rates: 10%, 50%, and 80%
    
    if fresh>1
        savethis=[];
    else %continue a paused simulation
        load A7; P0=savethis(end,:); [P0 size(savethis)]
        
        %P0 contains, for each of the paused simulation's populations, the
        %number of RM organisms; this information is used (see statements
        %below) to reconstruct the population vectors (decimate, halfdie,
        %mostdie), so that the simulation can be continued
        if P0(2)>0
            decimatepop(100-P0(2)+1:100,1)=1;
        end
        if P0(4)>0
            halfdiepop(100-P0(4)+1:100,1)=1;
        end
        if P0(6)>0
            mostdiepop(100-P0(6)+1:100,1)=1;
        end
    end
end

while rounds>0 %outermost loop; loops over simulated generations
    
    savethis=[savethis; rounds sum(decimatepop) sum(halfdiepop) sum(mostdiepop)];
    %the simulation output ultimately saved: # of RM organisms in every
    %generation of every simulated population
    rounds=rounds-1; %initial value of "rounds" = # of generations simulated;
    %this line serves a "countdown" function
    if mod(rounds,10)==0 %output of simulation progress, for experimenter convenience
        savethis(end,:)
    end
    
    Odat=zeros(psize,2);
    %every row correspomds to a member of the population
    %values represent the reward accrued during the organism's lifetime
    %col 1 (2) = value accrued by a BH (RM) organism
    
    for j=1:psize %loop thru every member of the population
        events=zeros(life,2);
        %every row represents a choice instance
        %values represent reward obtained using BH (c1) or RM (c2)
        T1=100*rand(life,1); T2=100*rand(life,1); T3=max(T1,T2);
        %T1 & T2 are attribute values of presented items
        %T3 (T4) = attribute value of chosen item, if interface
        %does (not) differentiate the items
        T41=zeros(life,1); T42=T41; T4a=rand(life,1);
        T41(T4a<.5)=T1(T4a<.5); T42(T4a>.5)=T2(T4a>.5); T4=T41+T42;
        
        if envi==1
            b2=10; %percept boundary, BH
            E1a=T1<b2; E1b=T2<b2; E1=mod(E1a+E1b,2);
            %in line above, element k of E1=1 if interface differentiates
            %the items presented during life choice k; if both items are on
            %same side of perceptual boundary, E1=0
            E2a=zeros(life,1); E2b=E2a; E2a(E1==0)=T4(E1==0);
            E2b(E1==1)=T3(E1==1); E2c=E2b+E2a;
            %2 lines above create E2c; elements represent attribute values
            %of chosen items
            E2c(E2c<10)=lo; events(:,1)=E2c; %attributes-->reward
            
            %3 lines below: similar to above code block, but w/b2 value of
            %RM
            b2=19.5; E1a=T1<b2; E1b=T2<b2; E1=mod(E1a+E1b,2); E2a=zeros(life,1);
            E2b=E2a; E2a(E1==0)=T4(E1==0); E2b(E1==1)=T3(E1==1); E2c=E2b+E2a;
            E2c(E2c<10)=lo; events(:,2)=E2c;
        else
            HS=rand(life,1); HS=HS<p; %which choices are HS
            
            b2=50; E1a=T1<b2; E1b=T2<b2; E1=mod(E1a+E1b,2); E2a=zeros(life,1);
            E2b=E2a; E2a(E1==0)=T4(E1==0); E2b(E1==1)=T3(E1==1); E2c=E2b+E2a;
            %in above 2 lines, E2c represents attribute values of chosen
            %items, given a percept boundary at 50
            
            %during HS choices, RM does not differentiate items
            events(HS==1,2)=B*T4(HS==1);
            %BH has a percept boundary at 50 along both attributes
            events(HS==1,1)=B*E2c(HS==1);
            events(HS==0,1)=E2c(HS==0);
            
            %twobit(k)=1 if allocating 2 bits to detecting an attribute
            %differentiates T1 from T2
            twobit=abs(floor(T1/25)-floor(T2/25)); twobit=twobit>.1;
            E2a=zeros(life,1); E2b=E2a; E2a(twobit==0)=T4(twobit==0);
            E2b(twobit==1)=T3(twobit==1); E2c=E2b+E2a;
            events(HS==0,2)=E2c(HS==0);
        end
        Odat(j,:)=mean(events);
    end
    %decimatepop round update
    tInd=find(decimatepop(:,1),1); %find min index of RM members of pop
    decimatepop(1:tInd-1,2)=Odat(1:tInd-1,1); %reward obtained by BH organisms
    decimatepop(tInd:end,2)=Odat(tInd:end,2); %reward obtained by RM organisms
    A1=sortrows(decimatepop,2); %rank organisms by reward obtained
    A1=sum(A1(psize*.1+1:end,1)); %identify the survivors
    A2=sum(rand(1,psize*.1)<A1/(psize*.9)); %generate new members of population
    decimatepop=basepop; %initialize next generation
    decimatepop(psize-A1-A2+1:psize,1)=1; %initialize correct # of RM members
    %note: A1 & A2 are just intermediates used for calculations ...
    
    %halfdiepop round update (code similar to "decimatepop")
    tInd=find(halfdiepop(:,1),1);
    halfdiepop(1:tInd-1,2)=Odat(1:tInd-1,1);
    halfdiepop(tInd:end,2)=Odat(tInd:end,2);
    A1=sortrows(halfdiepop,2);
    A1=sum(A1(psize*.5+1:end,1));
    halfdiepop=basepop;
    halfdiepop(psize-A1*2+1:psize,1)=1;
    
    %mostdiepop round update (code similar to "decimatepop")
    tInd=find(mostdiepop(:,1),1);
    mostdiepop(1:tInd-1,2)=Odat(1:tInd-1,1);
    mostdiepop(tInd:end,2)=Odat(tInd:end,2);
    A1=sortrows(mostdiepop,2);
    A1=sum(A1(psize*.8+1:end,1));
    mostdiepop=basepop;
    mostdiepop(psize-A1*5+1:psize,1)=1;
end
[savethis(end,:) size(savethis)]
