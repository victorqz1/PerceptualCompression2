clear all; close all;
%The boxes in figs 2 and 3 are subdivided by lines. Here, each line is
%defined by its endpoints: x#(1),y#(1) and x#(2),y#(2).
%Figs 2/3 (4) => panel A (B)

for i=2:3
    figure(i); hold on
    switch i %Cases 1/2/3 respectively correspond to panels A/B/C.
        case 1
            x1a=100*(1-sqrt(2)/2); x3a=100*sqrt(2)/2; x1=[x1a 100];
            y1=[100 x1a]; x2=[0 100]; y2=[100 0]; x3=[0 x3a]; y3=[x3a 0];
        case 2
            x1=[25 25]; x2=x1+25; x3=x1+50; y1=[100 0]; y2=y1; y3=y1;
        case 3
            x1=[0 100]; y1=[50 50]; x2=[50 50]; y2=[100 0];
    end
    plot(x1,y1,'k','linewidth',1); plot(x2,y2,'k','linewidth',1);
    if i<3
        plot(x3,y3,'k','linewidth',1);
    end
    set(gca,'tickdir','out','ticklength',[.015 .015],'box','on')
    tk=0:100:100; set(gca,'linewidth',1.5,'fontsize',26,'xtick',tk,'ytick',tk)
    set(gca,'xlim',[0 100],'ylim',[0 100]); tk1={'0';'b_{1,1}'}; tk2={'0';'b_{2,1}'};
    set(gca,'xticklabel',tk1,'yticklabel',tk2)
    xlabel('Attribute 1','fontsize',26); axis('square')
    ylabel('Attribute 2','fontsize',26)
    switch i
        case 2
            title('AMR','fontsize',26)
        case 3
            title('BH','fontsize',26)
    end
end

figure(4); hold on
x=0:.1:100; y1=ones(1,101); y=[-300*y1 10.1:.1:100]; y1=[-325 105];
plot(x,y,'k','linewidth',1)
plot([10 10],y1,'b','linewidth',1) %BH boundary
plot([19.5 19.5],y1,'r','linewidth',1) %RM boundary
set(gca,'ylim',y1,'xtick',[0 100],'ytick',[-300 100])
xlabel('Attribute value','fontsize',26);
ylabel('Reward','fontsize',26);
legend('Reward','BH','AMR')

set(gca,'tickdir','out','ticklength',[.015 .015],'box','off','linewidth',...
    1.5,'fontsize',26); ch=get(gcf,'ch');
set(ch(1),'location','South','fontsize',26,'box','off')
