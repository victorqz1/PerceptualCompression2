close all; clear all

%the code block below is analogous to portions of the "integrate" code
%block in c_4a
NIV=zeros(6,1751); dev1=.1054; dev2=.1414; dev3=.3162;
for i=1:1751
    x=-.5+i*.001; NIV(1,i)=normpdf(x,0,dev1);
    NIV(2,i)=normpdf(x,0,dev2); NIV(3,i)=normpdf(x,0,dev3);
    NIV(4,i)=NIV(2,i)*normcdf(x,0,dev2);
    NIV(5,i)=NIV(1,i)*normcdf(x,0,dev3);
    NIV(6,i)=NIV(3,i)*normcdf(x,0,dev1);
end

%plot
figure(5); hold on; XV=.5:.001:2.25; plot(XV,NIV(4,:),'b','linewidth',1)
plot(XV,NIV(5,:),':r','linewidth',1); plot(XV,NIV(6,:),'r','linewidth',1)
set(gca,'tickdir','out','ticklength',[.015 .015],'linewidth',1.5,'fontsize',26)
set(gca,'box','off','xlim',[.65 2.1],'ylim',[0 2],'ytick',0:.6:1.8)
xlabel('Expected reward, preferred percept (R)','fontsize',26); ylabel('p(R)','fontsize',26)
legend('BH','AMR, P_{90} > P_{10}','AMR, P_{10} > P_{90}')
ch=get(gcf,'children'); set(ch(1),'box','off','fontsize',26,'location','Northeast')
