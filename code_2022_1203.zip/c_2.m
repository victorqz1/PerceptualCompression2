clear all; close all; figure(2)
%Values in bdat are derived in Part 6 of S1 Appendix
bdat=[25 62 16.4 25.4; 25 18.1 33.6 24.6; 25 11.3 33.6 24.6; 25 8.5 16.4 25.4]';
bgra=bar(bdat,'stacked');
set(bgra,'linestyle','none','barwidth',.5)
set(gca,'tickdir','out','ticklength',[.015 .015],'box','off','linewidth',1.5);
set(gca,'fontsize',26,'xlim',[.5 5.5],'ylim',[0 101]);
xl={'E2C';'E2C.1';'E2C.2';'E2C.3'};
set(gca,'xtick',[1 2 3 4],'xticklabel',xl)
xlabel('Environment','fontsize',26)
ylabel('Attribute value (% b_1)','fontsize',26)
legend('P1','P2','P3','P4'); ch=get(gcf,'children');
set(ch(1),'box','off','fontsize',26,'location','East')
