clear all; A=[]; B=[]; C=[]; D=[]; E=[]; F=[]; G=[];
H=[]; I=[]; J=[]; K=[]; L=[]; M=[];
cd PopSimulations %Data from simulations are stored in this folder.

%The files with prefix A-G (H-M) represent simulations in E3B (E3A).
%The files A1-A10 hold the raw data generated from 10 "condition A"
%simulations. The raw data are stored in the variable "savethis".
%In "savethis", the first and last row correspond to the first and last
%generation of the 3 populations whose evolutions were simulated.
%The loop below transfers to "A" the first and last row of each "savethis"
%from A1-A10, and stacks them vertically; similarly for B-M.
for i=1:10
    switch i
        case 1
            load A1; D1=[savethis(1,:); savethis(end,:)];
            load B1; D2=[savethis(1,:); savethis(end,:)];
            load C1; D3=[savethis(1,:); savethis(end,:)];
            load D1; D4=[savethis(1,:); savethis(end,:)];
            load E1; D5=[savethis(1,:); savethis(end,:)];
            load F1; D6=[savethis(1,:); savethis(end,:)];
            load G1; D7=[savethis(1,:); savethis(end,:)];
            load H1; D8=[savethis(1,:); savethis(end,:)];
            load I1; D9=[savethis(1,:); savethis(end,:)];
            load J1; D10=[savethis(1,:); savethis(end,:)];
            load K1; D11=[savethis(1,:); savethis(end,:)];
            load L1; D12=[savethis(1,:); savethis(end,:)];
            load M1; D13=[savethis(1,:); savethis(end,:)];
        case 2
            load A2; D1=[savethis(1,:); savethis(end,:)];
            load B2; D2=[savethis(1,:); savethis(end,:)];
            load C2; D3=[savethis(1,:); savethis(end,:)];
            load D2; D4=[savethis(1,:); savethis(end,:)];
            load E2; D5=[savethis(1,:); savethis(end,:)];
            load F2; D6=[savethis(1,:); savethis(end,:)];
            load G2; D7=[savethis(1,:); savethis(end,:)];
            load H2; D8=[savethis(1,:); savethis(end,:)];
            load I2; D9=[savethis(1,:); savethis(end,:)];
            load J2; D10=[savethis(1,:); savethis(end,:)];
            load K2; D11=[savethis(1,:); savethis(end,:)];
            load L2; D12=[savethis(1,:); savethis(end,:)];
            load M2; D13=[savethis(1,:); savethis(end,:)];
        case 3
            load A3; D1=[savethis(1,:); savethis(end,:)];
            load B3; D2=[savethis(1,:); savethis(end,:)];
            load C3; D3=[savethis(1,:); savethis(end,:)];
            load D3; D4=[savethis(1,:); savethis(end,:)];
            load E3; D5=[savethis(1,:); savethis(end,:)];
            load F3; D6=[savethis(1,:); savethis(end,:)];
            load G3; D7=[savethis(1,:); savethis(end,:)];
            load H3; D8=[savethis(1,:); savethis(end,:)];
            load I3; D9=[savethis(1,:); savethis(end,:)];
            load J3; D10=[savethis(1,:); savethis(end,:)];
            load K3; D11=[savethis(1,:); savethis(end,:)];
            load L3; D12=[savethis(1,:); savethis(end,:)];
            load M3; D13=[savethis(1,:); savethis(end,:)];
        case 4
            load A4; D1=[savethis(1,:); savethis(end,:)];
            load B4; D2=[savethis(1,:); savethis(end,:)];
            load C4; D3=[savethis(1,:); savethis(end,:)];
            load D4; D4=[savethis(1,:); savethis(end,:)];
            load E4; D5=[savethis(1,:); savethis(end,:)];
            load F4; D6=[savethis(1,:); savethis(end,:)];
            load G4; D7=[savethis(1,:); savethis(end,:)];
            load H4; D8=[savethis(1,:); savethis(end,:)];
            load I4; D9=[savethis(1,:); savethis(end,:)];
            load J4; D10=[savethis(1,:); savethis(end,:)];
            load K4; D11=[savethis(1,:); savethis(end,:)];
            load L4; D12=[savethis(1,:); savethis(end,:)];
            load M4; D13=[savethis(1,:); savethis(end,:)];
        case 5
            load A5; D1=[savethis(1,:); savethis(end,:)];
            load B5; D2=[savethis(1,:); savethis(end,:)];
            load C5; D3=[savethis(1,:); savethis(end,:)];
            load D5; D4=[savethis(1,:); savethis(end,:)];
            load E5; D5=[savethis(1,:); savethis(end,:)];
            load F5; D6=[savethis(1,:); savethis(end,:)];
            load G5; D7=[savethis(1,:); savethis(end,:)];
            load H5; D8=[savethis(1,:); savethis(end,:)];
            load I5; D9=[savethis(1,:); savethis(end,:)];
            load J5; D10=[savethis(1,:); savethis(end,:)];
            load K5; D11=[savethis(1,:); savethis(end,:)];
            load L5; D12=[savethis(1,:); savethis(end,:)];
            load M5; D13=[savethis(1,:); savethis(end,:)];
        case 6
            load A6; D1=[savethis(1,:); savethis(end,:)];
            load B6; D2=[savethis(1,:); savethis(end,:)];
            load C6; D3=[savethis(1,:); savethis(end,:)];
            load D6; D4=[savethis(1,:); savethis(end,:)];
            load E6; D5=[savethis(1,:); savethis(end,:)];
            load F6; D6=[savethis(1,:); savethis(end,:)];
            load G6; D7=[savethis(1,:); savethis(end,:)];
            load H6; D8=[savethis(1,:); savethis(end,:)];
            load I6; D9=[savethis(1,:); savethis(end,:)];
            load J6; D10=[savethis(1,:); savethis(end,:)];
            load K6; D11=[savethis(1,:); savethis(end,:)];
            load L6; D12=[savethis(1,:); savethis(end,:)];
            load M6; D13=[savethis(1,:); savethis(end,:)];
        case 7
            load A7; D1=[savethis(1,:); savethis(end,:)];
            load B7; D2=[savethis(1,:); savethis(end,:)];
            load C7; D3=[savethis(1,:); savethis(end,:)];
            load D7; D4=[savethis(1,:); savethis(end,:)];
            load E7; D5=[savethis(1,:); savethis(end,:)];
            load F7; D6=[savethis(1,:); savethis(end,:)];
            load G7; D7=[savethis(1,:); savethis(end,:)];
            load H7; D8=[savethis(1,:); savethis(end,:)];
            load I7; D9=[savethis(1,:); savethis(end,:)];
            load J7; D10=[savethis(1,:); savethis(end,:)];
            load K7; D11=[savethis(1,:); savethis(end,:)];
            load L7; D12=[savethis(1,:); savethis(end,:)];
            load M7; D13=[savethis(1,:); savethis(end,:)];
        case 8
            load A8; D1=[savethis(1,:); savethis(end,:)];
            load B8; D2=[savethis(1,:); savethis(end,:)];
            load C8; D3=[savethis(1,:); savethis(end,:)];
            load D8; D4=[savethis(1,:); savethis(end,:)];
            load E8; D5=[savethis(1,:); savethis(end,:)];
            load F8; D6=[savethis(1,:); savethis(end,:)];
            load G8; D7=[savethis(1,:); savethis(end,:)];
            load H8; D8=[savethis(1,:); savethis(end,:)];
            load I8; D9=[savethis(1,:); savethis(end,:)];
            load J8; D10=[savethis(1,:); savethis(end,:)];
            load K8; D11=[savethis(1,:); savethis(end,:)];
            load L8; D12=[savethis(1,:); savethis(end,:)];
            load M8; D13=[savethis(1,:); savethis(end,:)];
        case 9
            load A9; D1=[savethis(1,:); savethis(end,:)];
            load B9; D2=[savethis(1,:); savethis(end,:)];
            load C9; D3=[savethis(1,:); savethis(end,:)];
            load D9; D4=[savethis(1,:); savethis(end,:)];
            load E9; D5=[savethis(1,:); savethis(end,:)];
            load F9; D6=[savethis(1,:); savethis(end,:)];
            load G9; D7=[savethis(1,:); savethis(end,:)];
            load H9; D8=[savethis(1,:); savethis(end,:)];
            load I9; D9=[savethis(1,:); savethis(end,:)];
            load J9; D10=[savethis(1,:); savethis(end,:)];
            load K9; D11=[savethis(1,:); savethis(end,:)];
            load L9; D12=[savethis(1,:); savethis(end,:)];
            load M9; D13=[savethis(1,:); savethis(end,:)];
        case 10
            load A10; D1=[savethis(1,:); savethis(end,:)];
            load B10; D2=[savethis(1,:); savethis(end,:)];
            load C10; D3=[savethis(1,:); savethis(end,:)];
            load D10; D4=[savethis(1,:); savethis(end,:)];
            load E10; D5=[savethis(1,:); savethis(end,:)];
            load F10; D6=[savethis(1,:); savethis(end,:)];
            load G10; D7=[savethis(1,:); savethis(end,:)];
            load H10; D8=[savethis(1,:); savethis(end,:)];
            load I10; D9=[savethis(1,:); savethis(end,:)];
            load J10; D10=[savethis(1,:); savethis(end,:)];
            load K10; D11=[savethis(1,:); savethis(end,:)];
            load L10; D12=[savethis(1,:); savethis(end,:)];
            load M10; D13=[savethis(1,:); savethis(end,:)];
    end
    A=[A; D1]; B=[B; D2]; C=[C; D3]; D=[D; D4]; E=[E; D5]; F=[F; D6]; G=[G; D7];
    H=[H; D8]; I=[I; D9]; J=[J; D10]; K=[K; D11]; L=[L; D12]; M=[M; D13];
end

raw=input('which output?');
switch raw
    case 1
        %The raw data displayed is as described in the above comment block.
        %Case 4 (1) displays raw data from environment E3A (E3B).
        A
        B
        C
        D
        E
        F
        G
    case 2
        %This option displays, for every simulated population, the final count
        %of RM organisms.
        %Every row corresponds to a simulation replicate.
        %Every column triplet corresponds to a simulation condition.
        %Within a triplet, the three columns correspond to populations evolving
        %with survival rates of 90%, 50%, and 20% (respectively).
        [A(2:2:end,2:2:6) B(2:2:end,2:2:6) C(2:2:end,2:2:6)]
        [D(2:2:end,2:2:6) E(2:2:end,2:2:6) F(2:2:end,2:2:6) G(2:2:end,2:2:6)]
    case 3
        x2d=zeros(10,7);
        %x2d aggregates the "column 3" from every triplet mentioned above (see
        %"raw==2").
        x2d(:,1)=A(2:2:end,6); x2d(:,2)=B(2:2:end,6); x2d(:,3)=C(2:2:end,6);
        x2d(:,4)=D(2:2:end,6); x2d(:,5)=E(2:2:end,6); x2d(:,6)=F(2:2:end,6);
        x2d(:,7)=G(2:2:end,6); x2d
        
        x2d=sum(x2d/100); dOut=zeros(7,1);
        for i=1:7
            switch i
                case 1
                    X=x2d(1); Y=x2d(2);
                case 2
                    X=x2d(1); Y=x2d(3);
                case 3
                    X=x2d(4); Y=x2d(2);
                case 4
                    X=x2d(6); Y=x2d(3);
                case 5
                    X=x2d(4); Y=x2d(5);
                case 6
                    X=x2d(6); Y=x2d(5);
                case 7
                    X=x2d(6); Y=x2d(7);
            end
            %For each pair of simulation conditions compared, X and Y represent
            %each condition's # of RM fixations.
            K=X+Y; x=min(X,Y); dOut(i)=2*hygecdf(x,20,K,10);
        end
        dOut
        %The null hypothesis that RM fixation is equally likely for the
        %two conditions is tested with the 2-tailed hypergeometric test,
        %and the p-value is stored in dOut.
    case 4
        %see case 1
        H
        I
        J
        K
        L
        M
    case 5
        %x2d contains the final count of RM organisms from every
        %simulation in E3A with a 20% survival rate.
        %As in case 3, rows are simulation replicates; columns (left to
        %right) respectively correspond to the conditions specified in the
        %rows (top to bottom) of Table 2.
        x2d=zeros(10,6);
        x2d(:,1)=H(2:2:end,2); x2d(:,2)=I(2:2:end,2); x2d(:,3)=J(2:2:end,2);
        x2d(:,4)=K(2:2:end,2); x2d(:,5)=L(2:2:end,2); x2d(:,6)=M(2:2:end,2);
        dOut=zeros(2,6); x1=sum(x2d/100); dOut(1,:)=x1; x1=min(x1,10-x1);
        dOut(2,:)=binocdf(x1,10,.5)*2
        %Here, the null hypothesis is that RM fixation probability is
        %50%, and agnostic of simulation conditions.
end
cd ..