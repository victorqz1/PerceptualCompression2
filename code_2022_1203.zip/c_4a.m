clear all; close all; xval=2:51;

%The code block "integrate" computes E(P1) (E(P2)) when E(P1)>E(P2)
%(E(P2)>E(P1))
%Values of E(P1) (E(P2)) are stored in col 2 (1) of Ev
%Rows (1,2,3) of Ev correspond to size(P2)=(50,30,10)
%EvA (EvG) stores the arithmetic (geometric) mean rewards obtained, given
%a particular perceptual configuration (columns correspond to different
%sizes of P2) and a particular number of items presented (row n represents
%the case of n+1 items)
Ev=zeros(3,2); EvA=zeros(50,3); EvG=EvA;

%integrate
%here, NIV stores the values that are added to approximate the integrals
%dev1 (dev2) is the sd of percept 2 (1)
%r=(1,2,3) correspond to size(P2)=(50,30,10)
for r=1:3
    m=20*(r-1); dev1=1/sqrt(50-m); dev2=1/sqrt(50+m); NIV=zeros(2,10001);
    for i=1:10001
        x=-5.001+i*.001; A1=normpdf(x,0,dev1); A2=normcdf(x,0,dev2);
        A3=normpdf(x,0,dev2); A4=normcdf(x,0,dev1);
        NIV(1,i)=A1*A2*x; NIV(2,i)=A3*A4*x;
    end
    A1=sum(NIV,2)/1000; Ev(r,:)=A1';
end

%After E(P) are computed, the next step is to compute E(O) for both percept
%orderings; then, the mean rewards for given perceptual configurations can
%be computed
%(rr, j, r) loop through values of (mu, n, size(P2))
%In matrices Ea1, P, and Ea, rows differ according to size(P2) (as in Ev)
%In Ea1, columns 1-4 correspond to E(P22), E(P11), E(P12), and E(P21);
%here, E(PXY) is the expected value of percept Y when percept X is the
%higher-valued percept
%The columns in P correspond to the values that are multiplied by the
%contents of Ea1 during the computation of E(O) values; for example, the
%computation of E(O1) uses the product E(P12)*(S2/100)^n, and since
%E(P12) is in col 3 of Ea1, values of (S2/100)^n are in col 3 of P

for rr=1:2
    switch rr
        case 1
            mu=1;
    end
    Ea1=Ev+mu/2; Ea1=[Ea1*2 -2*Ea1+2*mu];
    for j=2:51
        P=zeros(3,4);
        for r=1:3
            b=50+20*(r-1); b1=(100-b)/100; b2=b/100;
            P(r,:)=[1-b1^j 1-b2^j b2^j b1^j];
        end
        Ea=Ea1.*P; EvA(j-1,:)=sum(Ea,2)'/2;
        Eb=Ea(:,1)+Ea(:,4); Ec=Ea(:,3)+Ea(:,2); Ed=(Eb.*Ec)';
        if rr<2
            EvG(j-1,:)=Ed;
        else
            EvG(j-1,:)=sqrt(Ed);
        end
    end
    
    %plots
    if rr==1
        Pl=EvA;
    else
        Pl=EvG;
    end
    figure; hold on
    plot(xval,Pl(:,1),'b','linewidth',1); plot(xval,Pl(:,3),'r','linewidth',1)
    set(gca,'tickdir','out','ticklength',[.015 .015],'linewidth',1.5,'fontsize',26)
    xlabel('Number of choices (n)','fontsize',26)
    set(gca,'box','off','xtick',0:10:50,'xlim',[0 52])
    switch rr
        case 1
            ylabel('AMR','fontsize',26)
            title('u=1','fontsize',26)
            legend('BH','AMR','location','Southeast')
            ch=get(gcf,'children'); set(ch(1),'box','off','fontsize',26)
        case 2
            ylabel('GMR','fontsize',26)
            title('u=1','fontsize',26)
    end
end