clear all; close all

%generate data
vals=zeros(12,4); prob=vals;
for i=1:4
    switch i
        case 1
            a=59.75; b=-146.66; c=.038;
        case 2
            a=55; b=-300; c=.01;
        case 3
            a=65.6; b=550; c=.02;
        case 4
            a=62.5; b=687.5; c=.02;
    end
    c=c*100;
    for j=1:12
        vals(j,i)=(j-1)*b+(101-j)*a;
        prob(j,i)=c^(j-1)*exp(-c)/factorial(j-1);
    end
end

prob(:,3)=prob(12:-1:1,3); prob(:,4)=prob(12:-1:1,4);
vals(:,3)=vals(12:-1:1,3); vals(:,4)=vals(12:-1:1,4);
for j=1:4
    yy=zeros(1,14000); i=12; yl=3001;
    while i>0
        if vals(i,j)<3001
        else
            yy(yl:round(vals(i,j)))=sum(prob(i+1:12,j)); yl=round(vals(i,j));
        end
        i=i-1;
    end
    yy(yl:end)=1;
    switch j
        case 1
            y1=yy;
        case 2
            y2=yy;
        case 3
            y3=yy;
        case 4
            y4=yy;
    end
end

figure(5); hold on
plot(3001:6000,y2(3001:6000),'b','linewidth',1)
plot(3001:6000,y1(3001:6000),'r','linewidth',1)
plot([4763 4763],[0 1],'k','linewidth',1)
plot([600 600],[.5 6],'y','linewidth',1)

set(gca,'xlim',[3500 6000],'ytick',0:.5:1,'xtick',3500:1000:5500)
xlabel('Reward','fontsize',26);
ylabel('Cumulative probability','fontsize',26);
thresh=sprintf('Offspring%sthreshold',char(10));
legend('BH','AMR',thresh); title('E3A','fontsize',26)


set(gca,'tickdir','out','ticklength',[.015 .015],'box','off','linewidth',...
    1.5,'fontsize',26,'ytick',0:.25:1);
ch=get(gcf,'ch'); set(ch(1),'location','Northwest','fontsize',26,'box','off')

text(3550,.28,'Bottom 10%','color','k','fontsize',26)
text(3550,.18,'4','color','b','fontsize',26)
text(3550,.08,'6','color','r','fontsize',26)

figure(6); hold on
plot(6001:11500,y4(6001:11500),'b','linewidth',1)
plot(6001:11500,y3(6001:11500),'r','linewidth',1)
plot([8068 8068],[0 1],'k','linewidth',1)
plot([600 600],[.5 6],'y','linewidth',1)

set(gca,'xlim',[6000 10500],'ytick',0:.5:1,'xtick',6000:2000:10000)
xlabel('Reward','fontsize',26);
ylabel('Cumulative probability','fontsize',26);
legend('BH','AMR',thresh); title('E3B','fontsize',26)

set(gca,'tickdir','out','ticklength',[.015 .015],'box','off','linewidth',...
    1.5,'fontsize',26,'ytick',0:.25:1);
ch=get(gcf,'ch'); set(ch(1),'location','Southeast','fontsize',26,'box','off')

text(8400,.7,'Top 20%','color','k','fontsize',26)
text(8400,.6,'13','color','b','fontsize',26)
text(8400,.5,'7','color','r','fontsize',26)