clear all; close all;
%In code below, figures 1/2 => panels A/B.

%b1a and b1b denote the endpoints of the lines depicting the placement of b2
%xa and ya are used to plot item probabilities
figure(1), hold on; b1a=[65 65.01]; b1b=[0 .022];
xa=0:.1:100; ya=[zeros(1,501)+.005 zeros(1,500)+.015];
plot(xa,ya,'b','linewidth',1); plot(b1a,b1b,'r','linewidth',1)
set(gca,'tickdir','out','ticklength',[.015 .015],'box','off')
set(gca,'linewidth',1.5,'fontsize',26,'xtick',0:50:100)
yl={'0';'a';'1';'(1+a)';'2'};
set(gca,'ylim',[0 .022],'ytick',0:.005:.02,'yticklabel',yl)
xlabel('Attribute value (% b_1)','fontsize',26)
ylabel('p(item)/b_1','fontsize',26)
legend('p(item)','b_2'); ch=get(gcf,'children');
set(ch(1),'box','off','fontsize',26,'location','Northwest')

figure(2); hold on
a=0:.01:1; bmaxMI=(a+.5)./(a+1); bmaxR=.5+.25*a;
plot(bmaxMI,'b','linewidth',1); plot(bmaxR,'r','linewidth',1)
set(gca,'xlim',[0 100],'xtick',0:20:100,'xticklabel',0:.2:1)
set(gca,'ylim',[.5 .76],'ytick',.5:.05:.75,'yticklabel',50:5:75)
set(gca,'tickdir','out','ticklength',[.015 .015],'box','off')
set(gca,'linewidth',1.5,'fontsize',26)
xlabel('a','fontsize',26); ylabel('Optimal b_2 (% b_1)','fontsize',26)
legend('MI','AMR'); ch=get(gcf,'children');
set(ch(1),'box','off','fontsize',26,'location','NorthWest')
